// Estas líneas modifican la configuración directamente
interfaceConfig.DEFAULT_LOGO_URL = 'images/brandingnew.png';
interfaceConfig.SHOW_JITSI_WATERMARK = true;
interfaceConfig.SHOW_BRAND_WATERMARK = false;
interfaceConfig.JITSI_WATERMARK_LINK = '';
interfaceConfig.APP_NAME = 'Centro de Seguridad';