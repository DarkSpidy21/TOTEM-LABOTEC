// --- CONFIGURACIÓN FINAL (MODO LOCAL) --- Crear carpeta custom-config.js y poner lo siguiente

// 1. Quitar botones (Limpio)
config.toolbarButtons = [ 'hangup' , "camera","microphone","participants-pane"];
config.prejoinConfig = {
    enabled: false};
config.welcomePage = {
    disabled: true};
config.startWithVideo={
    enabled: true};
condif.startWithAudio={
    disabled: false};